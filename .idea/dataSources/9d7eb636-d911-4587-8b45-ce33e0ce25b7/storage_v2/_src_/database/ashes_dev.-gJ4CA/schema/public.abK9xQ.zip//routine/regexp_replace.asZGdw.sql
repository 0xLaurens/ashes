create function regexp_replace(citext, citext, text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
    SELECT pg_catalog.regexp_replace( $1::pg_catalog.text, $2::pg_catalog.text, $3, 'i');
$$;

alter function regexp_replace(citext, citext, text) owner to postgres;

